# download the ckpt files under ./group2/
